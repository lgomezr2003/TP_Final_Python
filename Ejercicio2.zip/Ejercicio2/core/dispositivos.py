"""Clases de dispositivos del catálogo"""

from dataclasses import dataclass, field
from core.excepciones import StockInvalidoError

@dataclass
class DispositivoEcologico:
    
    """ Clase base """
    
    modelo: str
    precio: float
    _stock: int = field(default=0, repr=False)
    """
    def stock(self, valor: int) -> None:
         Setter que no acepta negativos
        if not isinstance(valor, int):
            raise StockInvalidoError(valor)
        if valor < 0:
            raise StockInvalidoError(valor)
        self._stock = valor
    
    def ficha_tecnica(self) -> str:
        Ficha técnica, para subclases
        return (
            f"Modelo: {self.modelo}\n"
            f"Precio: ${self.precio:.2f}\n"
            f"Stock: {self.stock} unidades"
        )
    """
    def __post_init__(self) -> None:
        """Valida stock"""
        self.stock = self._stock
    @property
    def stock(self, valor: int) -> None:
        """ Setter """
        if not isinstance(valor, int):
            raise StockInvalidoError(valor)
        if valor < 0:
            raise StockInvalidoError(valor)
        self._stock = valor
        
    def ficha_tecnica(self) -> str:
        """Ficha técnica genérica"""
        return (
            f"Modelo: {self.modelo}\n"
            f"Precio:${self.precio:2f}\n"
            f"Stock: {self.stock} unidades"
        )
        
@dataclass
class PanelSolar(DispositivoEcologico):
    """ Hereda de la clase base y agrega atributos"""
    potencia_w: float = 0.0 
    eficiencia: float = 0.0
    
def ficha_tecnica(self) -> str:
    """ Incluye atributos del panel"""
    
    base = super().ficha_tecnica()
    return(
        f"{base}\n"
        f"Potencia: {self.potencia_W} W\n"
        f"Eficiencia: {self.eficiencia}%"
    )
    